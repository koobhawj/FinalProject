package edu.century.FinalProject;



import javax.swing.JOptionPane;

public class TicTacToe
{

	public TicTacToe()
	{
	}

	public static void main(String args[])
	{
		JOptionPane.showMessageDialog(null, "Starting Game..");
		new GUI();
	}
}
